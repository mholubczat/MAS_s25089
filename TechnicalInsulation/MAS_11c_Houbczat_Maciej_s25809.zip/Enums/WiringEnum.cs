namespace TechnicalInsulation.Enums;

public enum WiringEnum
{
    Galvanized, Stainless
}