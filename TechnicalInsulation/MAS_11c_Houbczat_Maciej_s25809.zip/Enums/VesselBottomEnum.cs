namespace TechnicalInsulation.Enums;

public enum VesselBottomEnum
{
    Flat, Sphere, Zeppelin, Cone
}