namespace TechnicalInsulation.Enums;

public enum DuctType
{
    Round, Rectangular
}