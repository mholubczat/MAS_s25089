namespace TechnicalInsulation.Enums;

public enum ProfileEnum
{
    Flat, Trapezoid, Diagonal, Perforated
}