namespace TechnicalInsulation.Enums;

public enum PipelineTypeEnum
{
    Pipe, Valve, Elbow, Tee, Reduction, Cap
}