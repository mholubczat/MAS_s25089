namespace TechnicalInsulation.Enums;

public enum EnvironmentalCorrosivityCategoryEnum
{
    C1, C2, C3, C4, C5I, C5M
}