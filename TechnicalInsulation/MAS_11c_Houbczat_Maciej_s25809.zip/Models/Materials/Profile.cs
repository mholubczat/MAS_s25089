namespace TechnicalInsulation.Models.Materials;

public class Profile
{
    public int ProfileId { get; init; }
    public string Name { get; init; } = null!;
}