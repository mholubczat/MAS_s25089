namespace TechnicalInsulation.Models.Materials;

public class Wiring
{
    public int WiringId { get; init; }
    public string Name { get; init; } = null!;
}