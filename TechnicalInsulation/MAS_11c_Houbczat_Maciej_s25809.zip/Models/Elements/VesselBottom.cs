using TechnicalInsulation.Enums;

namespace TechnicalInsulation.Models.Elements;

public class VesselBottom
{
    public int VesselBottomId { get; init; }
    public string Name { get; init; } = null!;
}