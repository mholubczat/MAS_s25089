namespace TechnicalInsulation.Models;

public class EnvironmentalCorrosivityCategory
{
    public int EnvironmentalCorrosivityCategoryId { get; init; }

    public string Name { get; init; } = null!;
}